'use strict';

//First 2 lines do the same thing

const score0 = document.querySelector('#score--0');
const score1 = document.getElementById('score--1');
const dice = document.querySelector('.dice'); //the dice image
const btnRoll = document.querySelector('.btn--roll');
const btnHold = document.querySelector('.btn--hold');
const btnNew = document.querySelector('.btn--new');
const curr0 = document.getElementById('current--0');
const curr1 = document.getElementById('current--1');
const totscore = [0, 0];
const player0 = document.querySelector('.player--0');
const player1 = document.querySelector('.player--1');
let currScore = 0;
let player = 0;
let playing = true;

const switchpl = function () {
  document.getElementById(`current--${player}`).textContent = 0;
  player = player === 0 ? 1 : 0;
  currScore = 0;
  player0.classList.toggle('player--active');
  player1.classList.toggle('player--active');
};

//Reseeting the game
score0.textContent = 0;
score1.textContent = 0;
dice.classList.add('hidden');

console.log(btnRoll.textContent);

btnRoll.addEventListener('click', function () {
  if (playing) {
    const value = Math.trunc(Math.random() * 6) + 1;
    console.log(value);
    dice.classList.remove('hidden');
    dice.src = `dice-${value}.png`;
    if (value !== 1) {
      currScore += value;
      document.getElementById(`current--${player}`).textContent = currScore;
    } else {
      switchpl();
    }
  }
});

btnHold.addEventListener('click', function () {
  if (playing) {
    totscore[player] += currScore;
    document.getElementById(`score--${player}`).textContent = totscore[player];

    //check if won
    if (totscore[player] >= 100) {
      playing = false;
      document
        .querySelector(`.player--${player}`)
        .classList.add('player--winner');

      document
        .querySelector(`.player--${player}`)
        .classList.remove('player--active');

      dice.classList.add('hidden');
    } else {
      switchpl();
    }
  }
});

btnNew.addEventListener('click', function () {
  playing = true;
  totscore.fill(0);
  score0.textContent = 0;
  score1.textContent = 0;
  currScore = 0;
  curr0.textContent = 0;
  curr1.textContent = 0;
  player0.classList.remove('player--winner');
  player1.classList.remove('player--winner');

  player0.classList.add('player--active');
  player1.classList.remove('player--active');

  player = 0;
});
