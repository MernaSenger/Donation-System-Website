var formfield = document.getElementById("formfield");
var uploadButtonPressed = false;

function add() {
  var newField = document.createElement("input");
  newField.setAttribute("type", "text");
  newField.setAttribute("name", "text");
  newField.setAttribute("class", "text");
  newField.setAttribute("siz", 50);
  newField.setAttribute("placeholder", "Optional Field");
  formfield.appendChild(newField);
}

function remove() {
  var input_tags = formfield.getElementsByTagName("input");
  if (input_tags.length > 2) {
    formfield.removeChild(input_tags[input_tags.length - 1]);
  }
}

function redirect() {
  var selectedValue = document.getElementById("dropdownMenu").value;

  // Log the selected value to the console
  console.log("Selected value: " + selectedValue);

  // Perform redirection based on the selected value
  if (selectedValue === "doctorReg.html") {
    window.location.href = "doctorReg.html";
  } else if (selectedValue === "donate.html") {
    window.location.href = "donate.html";
  } else if (selectedValue === "teacherReg.html") {
    window.location.href = "teacherReg.html";
  } else {
    console.log("Invalid selection");
  }
}

function showAlert(message) {
  // JUST DISMISS THE ALERTBOX
  var alertText = document.getElementById("alertText");
  alertText.textContent = message;
  var alertBox = document.getElementById("alertBox");
  alertBox.classList.add("show");
  return false;
}

function dismissAlert() {
  var alertBox = document.getElementById("alertBox");
  alertBox.classList.remove("show");
}

function showAlert1(message) {
  //REDIRECT TO ANOTHER PAGE
  var alertText = document.getElementById("alertText1");
  alertText.textContent = message;
  var alertBox = document.getElementById("alertBox1");
  alertBox.classList.add("show");
  console.log("Alert2");
  return false;
}

function dismissAlert1() {
  // var alertBox = document.getElementById("alertBox");
  window.location.href = "home.html";
}

function chooselevel(box, select) {
  if (box.checked && select === "Select") return false;
  else return true;
}

function chooselevel2(box, select) {
  if (!box.checked && select !== "Select") return false;
  else return true;
}

function validateForm() {
  // DOCTOR
  var fname = document.getElementById("fname").value;
  var lastname = document.getElementById("lname").value;
  var mail = document.getElementById("mail").value;
  var contact = document.getElementById("contact").value;
  var pass = document.getElementById("pass").value;
  var gender = document.getElementById("Gender").value;
  var address = document.getElementById("address").value;
  // var reg = document.getElementById("dropdownMenu").value;
  var area = document.getElementById("area").value;
  var gov = document.getElementById("Governate").value;
  var label1 = document.getElementById("labeloo").value;
  var speciality = document.getElementById("Speciality").value;
  var address1 = document.getElementById("address1").value;
  var area1 = document.getElementById("area1").value;
  var gov1 = document.getElementById("Governate1").value;

  var fileInput = document.getElementById("document");
  var fileUploaded = fileInput.files.length > 0;
  var uploadedDocument = document.getElementById("uploadedDocument");
  console.log("up" + uploadedDocument);
  console.log("hi2,", uploadButtonPressed);

  console.log("GOV");
  if (
    fname === "" ||
    lastname === "" ||
    mail === "" ||
    contact === "" ||
    pass === "" ||
    gender === "Select" ||
    address === "" ||
    area === "" ||
    gov === "Select" ||
    label1 === "" ||
    speciality === "Select" ||
    address1 === "" ||
    area1 === "" ||
    gov1 === "Select" ||
    !fileUploaded
  ) {
    return showAlert("Please fill in all fields.");
  } else if (!pinPlaced()) {
    return showAlert("Please pin your clinic location.");
  } else if (!uploadButtonPressed) {
    return showAlert("Please upload the chosen document.");
  } else {
    // window.location.href = "about-us.html";
    return showAlert1("Your registrartion is pending admin approval.");
  }
}

function validateForm2() {
  // TEACHER
  var fname = document.getElementById("fname").value;
  var lastname = document.getElementById("lname").value;
  var mail = document.getElementById("mail").value;
  var contact = document.getElementById("contact").value;
  var pass = document.getElementById("pass").value;
  var gender = document.getElementById("Gender").value;
  var address = document.getElementById("address").value;
  // var reg = document.getElementById("dropdownMenu").value;
  var area = document.getElementById("area").value;
  var gov = document.getElementById("Governate").value;
  var label1 = document.getElementById("labeloo").value;
  var label2 = document.getElementById("labeloo2").value;
  var box1 = document.getElementById("scienceCheckbox");
  var box2 = document.getElementById("mathCheckbox");
  var box3 = document.getElementById("historyCheckbox");
  var box4 = document.getElementById("languageCheckbox");
  var math = document.getElementById("mathGrade").value;
  var sci = document.getElementById("sci").value;
  var his = document.getElementById("his").value;
  var lang = document.getElementById("Lang").value;

  var fileInput = document.getElementById("document");
  var fileUploaded = fileInput.files.length > 0;

  console.log("up", !uploadButtonPressed);

  if (
    fname === "" ||
    lastname === "" ||
    mail === "" ||
    contact === "" ||
    pass === "" ||
    gender === "" ||
    address === "" ||
    area === "" ||
    gov === "" ||
    label1 === "" ||
    label2 === "" ||
    !fileUploaded
  ) {
    console.log("here");
    return showAlert("Please fill in all fields.");
  } else if (!uploadButtonPressed) {
    return showAlert("Please upload the chosen document.");
  } else if (!(box1.checked || box2.checked || box3.checked || box4.checked)) {
    return showAlert("Please choose a speciality.");
  } else if (
    !(
      chooselevel(box1, sci) &&
      chooselevel(box2, math) &&
      chooselevel(box3, his) &&
      chooselevel(box4, lang)
    )
  ) {
    return showAlert("Please choose an Education Level.");
  } else if (
    !(
      chooselevel2(box1, sci) &&
      chooselevel2(box2, math) &&
      chooselevel2(box3, his) &&
      chooselevel2(box4, lang)
    )
  ) {
    return showAlert(
      "Please choose for each speciality an education level and vice versa."
    );
  } else {
    // window.location.href = "about-us.html";
    return showAlert1("Your registrartion is pending admin approval.");
  }
}

function validateForm3() {
  // REGULAR DONOR
  var fname = document.getElementById("fname").value;
  var lastname = document.getElementById("lname").value;
  var mail = document.getElementById("mail").value;
  var contact = document.getElementById("contact").value;
  var pass = document.getElementById("pass").value;
  var gender = document.getElementById("Gender").value;
  var address = document.getElementById("address").value;
  // var reg = document.getElementById("dropdownMenu").value;
  var area = document.getElementById("area").value;
  var gov = document.getElementById("Governate").value;

  // console.log("GOV");
  // if (
  //   fname === "" ||
  //   lastname === "" ||
  //   mail === "" ||
  //   contact === "" ||
  //   pass === "" ||
  //   gender === "Select" ||
  //   address === "" ||
  //   area === "" ||
  //   gov === "Select"
  // ) {
  //   return showAlert("Please fill in all fields.");
  // } else {
  // window.location.href = "about-us.html";
  return showAlert1("Your registrartion is pending admin approval.");
}

// Function to display the uploaded document
function displayUploadedDocument() {
  var fileInput = document.getElementById("document");
  var uploadedDocument = document.getElementById("uploadedDocument");

  if (fileInput.files.length > 0) {
    var file = fileInput.files[0];
    var reader = new FileReader();

    reader.onload = function (e) {
      // Create a link to download the uploaded document
      var downloadLink = document.createElement("a");
      downloadLink.href = e.target.result;
      downloadLink.textContent = file.name;
      downloadLink.setAttribute("download", file.name);

      // Append the link to the uploadedDocument div
      uploadedDocument.innerHTML = "";
      uploadedDocument.appendChild(downloadLink);

      // Trigger the download automatically
      downloadLink.click();
    };

    // Read the uploaded file as data URL
    reader.readAsDataURL(file);
  } else {
    uploadedDocument.innerHTML = "No document uploaded.";
  }
  uploadButtonPressed = true;
}

function innerFormSubmit() {
  // Handle inner form submission
  console.log("Inner form submitted");
  return false; // Returning false prevents the form from submitting
}

function redirectHana() {
  console.log("hana");
  // window.location.href = "merna-health.html";
}

// function displayUploadedDocument() {
//   var fileInput = document.getElementById("document");
//   var uploadedDocument = document.getElementById("uploadedDocument");

//   if (fileInput.files.length > 0) {
//     var file = fileInput.files[0];
//     var reader = new FileReader();

//     reader.onload = function (e) {
//       // Create a link to download the uploaded document
//       var downloadLink = document.createElement("a");
//       downloadLink.href = e.target.result;
//       downloadLink.textContent = file.name;
//       downloadLink.setAttribute("download", file.name);

//       // Append the link to the uploadedDocument div
//       var documentContainer = document.createElement("span");
//       documentContainer.textContent = "Uploaded Document: ";
//       documentContainer.appendChild(downloadLink);
//       var additionalText = document.createTextNode(" ");
//       documentContainer.appendChild(additionalText);
//       uploadedDocument.appendChild(documentContainer);
//     };

//     // Read the uploaded file as data URL
//     reader.readAsDataURL(file);
//   } else {
//     uploadedDocument.innerHTML = "No document uploaded.";
//   }
// }

// Attach event listener to form submission

// MAPPP BELOWWWW
